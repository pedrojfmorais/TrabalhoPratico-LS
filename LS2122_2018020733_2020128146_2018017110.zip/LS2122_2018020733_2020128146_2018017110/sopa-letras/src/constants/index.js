export const PALAVRAS_POSSIVEIS = [
    'REACT', 
    'JAVASCRIPT', 
    'HTML', 
    'CSS', 
    'BACKBONE', 
    'ANGULAR', 
    'SVELTE', 
    'EMBER', 
    'BOOTSTRAP', 
    'VUE', 
    'JAVA', 
    'PYTHON', 
    'SQL'
]; 
export const NUMERO_PALAVRAS_DIFICULDADE = [5, 7, 9];
export const NUMERO_LINHAS_DIFICULDADE = [10, 15, 20];
export const TEMPO_DIFICULDADE = [120, 90, 60];