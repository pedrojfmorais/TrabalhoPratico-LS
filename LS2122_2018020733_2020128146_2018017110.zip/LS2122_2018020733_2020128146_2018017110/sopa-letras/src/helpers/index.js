
export { default as initTabelaPalavras } from "./initTabelaPalavras";